import type { Metadata } from "next";
import { Inter, Poppins } from "next/font/google";
import "./globals.css";
const inter=Inter({subsets:["latin"],variable:"--font-inter"});
const poppins=Poppins({subsets:["latin"],weight:["400","500","600","700"],variable:"--font-poppins"});
export const metadata:Metadata={title:{default:"Nile Group | Global Exporter from India",template:"%s | Nile Group"},description:"Nile Group exporter."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body className={`${inter.variable} ${poppins.variable}`}>{children}</body></html>}
