export default function Home() {
  return (
    <main style={{padding:'2rem',fontFamily:'Arial'}}>
      <h1>Welcome to Nile Group</h1>
      <p>Premium Exporter of Fruits, Vegetables, Spices, Herbs, Organic Fertilizers and Seafood.</p>
    </main>
  );
}
